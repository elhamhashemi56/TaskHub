
import "./inbox.css"
import AddSection from "../AddSection"



const Inbox=()=>{
   return(
    <>
        <AddSection />
        {/* <ViewSections /> */}
    </>
   )
}

export default Inbox