
import "./inbox.css"
import AddSection from "../AddSection"
import ViewSections from "../ViewSections.js"


const Inbox=()=>{
   return(
    <>
        <AddSection />
        {/* <ViewSections /> */}
    </>
   )
}

export default Inbox