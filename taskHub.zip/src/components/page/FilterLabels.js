const FilterLabels=()=>{
    return (
        <div>
            FilterLabels
        </div>
    )
}

export default FilterLabels