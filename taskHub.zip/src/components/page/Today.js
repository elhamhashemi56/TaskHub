const Today=()=>{
    return (
        <div>
            Today
        </div>
    )
}

export default Today