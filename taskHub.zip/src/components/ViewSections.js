import "./viewSection.css"
import { Button,Form } from 'react-bootstrap';
import { useState,useRef  } from "react";
import CompletedTasks from "./CompletedTasks"
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const ViewSections=({sectionData,sectionIndex,setSection})=>{
    
    const [showTaskForm, setShowTaskForm] = useState(false);
    const [taskValue,setTaskValue]=useState(
        {
            taskName:"",
            taskDescription:""
        }
    )
    const [todos,setTodos]=useState([
        // {id: 1, sectionId:"", title: "item 1", done: false},
        // {id: 2, sectionId:"", title: "item 2", done: false},
        // {id: 3, sectionId:"", title: "item 3", done: false},
        // {id: 4, sectionId:"", title: "item 5", done: false},
        // {id: 5, sectionId:"", title: "item 6", done: false},
    ])

    const [selectedDate, setSelectedDate] = useState(null);
    const datepickerRef = useRef(null);

    const handleDateChange = (date) => {
    setSelectedDate(date);
    };
    
    const handleChangeTask=(e)=>{
        const newTaskValue = {...taskValue};
        console.log("e.target.value",e.target.value);
        newTaskValue[e.target.name] = e.target.value;
        setTaskValue(newTaskValue);
    }

  
    const toggleForm = () => {
        setShowTaskForm(!showTaskForm);
        
    }

    const handleCancel=()=>{
        taskValue.taskName=""
        taskValue.taskDescription=""
        toggleForm()
    }

    const handleAddTask=()=>{
        const lastId = todos.length > 0 ? todos[todos.length - 1].id : 0;
        const newTodo = {   
            title: taskValue.taskName,
            description: taskValue.taskDescription,
            sectionId:sectionIndex,
            done:false,
            id:lastId+1
          };
         console.log("newTodo",newTodo);
          setTodos([...todos,newTodo])
          setTaskValue({taskName:"",taskDescription:""})
          toggleForm()
    }


    const handleChangeDone=(id)=>{
        const newTodos = [...todos];
        newTodos.find(item=>item.id===id).done = true
        console.log("find",newTodos);
        setTodos(newTodos);
    }

    

    return(
        <div className="viewSection_Container mb-5">
            <div className="mb-2">
                <span className="sectionNameKlass ">{sectionData.sectionName}</span>
            </div>

            <div>
                {todos.filter(item=> !item.done).map(item=>{
                 return   <div className="itemsDontDone">
                            <input type="checkbox"
                                   className="mr-2" 
                                   value={item.done}
                                   onChange={()=>handleChangeDone(item.id)}
                                   />
                            {item.title}
                          </div>
                })}

                <h6>Completed Tasks</h6>
                {/* <CompletedTasks todos={todos}/> */}
                {todos.filter(item=> item.done).map(item=>{
                 return   <div className="itemsDone" >
                            {item.title}
                          </div>
                })}

                {/* <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Accordion Item #1
                    </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                    </div>
                    </div>
                </div>
                </div> */}

            </div>

            {!showTaskForm &&
            <div>
                <Button className="addTaskButton"
                        onClick={toggleForm}>+ Add Task
                
                </Button>
            </div>
            }

            {showTaskForm && (
                <Form className="task_container">
                    <input type="text"
                            placeholder="Enter Task Name"
                            className="form-control mb-3 ml-0 taskInput"
                            value={taskValue.taskName}
                            name={"taskName"}
                            onChange={handleChangeTask} 
                            />
                    <input type="text"
                            placeholder="Enter Description"
                            className="form-control mb-3 ml-0 taskInput"
                            value={taskValue.taskDescription}
                            name={"taskDescription"}
                            onChange={handleChangeTask}
                            
                            />
                            
                    <div className="iconsTaskForm"> 
                           
                        <div className="datePicker mr-2">
                            <img onClick={() => datepickerRef.current.setOpen(true)} className="svgInAddTask" src="/assets/icons/DueDate.svg" />
                            <DatePicker
                                        selected={selectedDate}
                                        onChange={handleDateChange}
                                        ref={datepickerRef}
                                    />
                        </div>
                        <div>
                            <img className="svgInAddTask mr-2" src="/assets/icons/Priority.svg" />
                        </div>
                        <div>
                            <img className="svgInAddTask" src="/assets/icons/Reminder.svg" />
                        </div>
                    </div>
                            
                             
                    <div className="line"></div>
                    <div className="buttonTask_Container">
                        <div>
                            <input></input>
                        </div>
                        <div>
                            <Button className="classPlusButton"
                                onClick={handleAddTask}
                                disabled={!taskValue.taskName}
                                >+
                            </Button>
                            <Button onClick={handleCancel} 
                                    className="cancelButton"
                                    >x
                            </Button>
                        </div>
                    </div>
                    
                </Form>
            )}
            
        </div>
        
    )
}

export default ViewSections