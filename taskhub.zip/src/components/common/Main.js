import React from 'react'
import NavbarMain from "./NavbarMain"
import Inbox from "../page/Inbox"
import Today from "../page/Today"
import Upcoming from "../page/Upcoming"
import FilterLabels from "../page/FilterLabels"
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Redirect
  } from "react-router-dom";
  
const Main = ()=>{

    return(
        <Router>
            <div id='main'>
                <NavbarMain />
                <Switch>
                    <Redirect exact path='/' to='/entry'></Redirect>
                    <Route path='/inbox'><Inbox /></Route>
                    <Route path='/today'><Today /></Route>
                    <Route path='/upcoming'><Upcoming /></Route>
                    <Route path='/filterLabels'><FilterLabels /></Route>
                </Switch>
            </div>
        </Router>
    
    )
    
}

export default Main