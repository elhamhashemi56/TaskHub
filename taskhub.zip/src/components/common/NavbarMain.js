const NavbarMain=()=>{
    return (
        <div>Navbar</div>
    )
}

export default NavbarMain